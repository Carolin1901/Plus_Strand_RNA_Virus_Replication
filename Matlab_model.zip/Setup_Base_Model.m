% please see for the syntax https://github.com/Data2Dynamics/d2d

arInit;
% load the data and link to the model
arLoadModel('Model_CVB');
arLoadData('CoxB3', 'Model_CVB');

arLoadModel('Model_DENV');
arLoadData('DENV', 'Model_DENV');

arLoadModel('Model_HCV');
arLoadData('HCV', 'Model_HCV');

arCompileAll;
ar.config.useFitErrorCorrection = 0;
ar.config.fiterrors = 0;

% estimated
arSetParsPattern('sd_', -1,1,1,-5,-1);
arSetParsPattern('mu', -1,1,1,-3,1);
arSetParsPattern('Ribo', log10(10),1,1,-3,2.5);
arSetParsPattern('rcRNAMax', log10(1),1,1,-3,2.5);
arSetParsPattern('fLuc', log10(1),1,1,-5,5);
arSetParsPattern('fmRNA_HCV', log10(1),1,1,-5,5);
arSetParsPattern('fpRNA_HCV', log10(1),1,1,-5,5);
arSetParsPattern('_init', log10(1),1,1,-2,log10(10));
arSetParsPattern('kre', -1,1,1,-2,1);
arSetParsPattern('ke', -1,1,1,-5,1);
arSetParsPattern('kf', -1,1,1,-5,1);

% fixed
arSetPars('KD_HCV', log10(0.04),2,1,-2,5);
arSetPars('KD_DV', log10(1.8),2,1,0,5);
arSetPars('KD_CVB', log10(40),2,1,0,5);
arSetPars('muL', log10(0.35),2,1,-3,5);

arSetPars('NPs_CVB', log10(60),2,1,0,4);
arSetPars('NPs_DV', log10(180),2,1,0,4);
arSetPars('NPs_HCV', log10(180),2,1,0,4);

arSetPars('k2_CVB', log10(300),2,1,-3,5);
arSetPars('k2_DV', log10(100),2,1,-3,5);
arSetPars('k2_HCV', log10(180),2,1,-3,5);

arSetPars('k4_CVB', log10(50),2,1,-3,5);
arSetPars('k4_DV', log10(1.01),2,1,-3,5);
arSetPars('k4_HCV', log10(1.1),2,1,-3,5);

arSetPars('muVirus_CVB', log10(0.08),2,1,-3,1);
arSetPars('muVirus_DV', log10(0.13),2,1,-3,1);
arSetPars('muVirus_HCV', log10(0.1),2,1,-3,1);

arSetPars('muVI', log10(0.23),2,1,-3,1);
arSetPars('muVI_HCV', log10(0.23),1,1,-3,1);
arSetPars('muVI_DV', log10(0.23),2,1,-3,1);
arSetPars('muVI_CVB', log10(0.23),1,1,-3,1);

arSetPars('muRP_CVB', log10(0.15),2,1,-3,1);
arSetPars('muRP_HCV', log10(0.26),2,1,-3,1);
arSetPars('muRP_DV', log10(0.23),2,1,-3,1);

arSetPars('muRC', log10(0.0862),2,1,-3,0);
arSetPars('muRC_HCV', log10(0.0862),2,1,-3,log10(0.0862));
arSetPars('muRC_DV', log10(0.0862),1,1,-3,log10(0.23));
arSetPars('muRC_CVB', log10(0.0862),1,1,-3,log10(0.15));

arSetPars('muP', log10(0.34),2,1,log10(0.05),0);
arSetPars('muP_HCV', log10(0.1),2,1,-2,0);
arSetPars('muP_DV', log10(0.46),2,1,-2,0);

% model fitting and plotting 
arFitLHS(500, [], [], true) 
arPlot;
arPrint;

